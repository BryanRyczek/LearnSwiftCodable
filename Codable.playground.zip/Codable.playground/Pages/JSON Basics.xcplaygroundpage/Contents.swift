//JSON BASICS

// array : surrounded by brackets []
// object : surrounded by curly braces {}
// name-value pair : "fieldName" : value

//valid values are:
//Number: Int or Floating Point (Double)
//String
//Bool
//array []
//object {}
//null (which is a value!)
