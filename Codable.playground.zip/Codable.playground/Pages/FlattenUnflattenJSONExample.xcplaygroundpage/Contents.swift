//: [Previous](@previous)

import Foundation

//It is a matter of preference, but sometimes you will want a "flat" object. For our purposes, let's imagine you want only the Business name, lat and long from the Sample.json file we worked with earlier

// No change at the top level.
struct BusinessResults : Codable {
    let results : [LocationData]
    
    enum CodingKeys : CodingKey, String {
        case results = "results"
    }
}

struct LocationData : Codable {

    // Here we define the "flat" structure we desire
    var name : String
    var lat : Double
    var lng : Double
    
    // "first level" keys
    enum CodingKeys: String, CodingKey {
        case name
        case location
    }
    
    // "second level" keys
    enum LocationKeys : String, CodingKey {
        case lat
        case lng
    }
    
}

//Let's look at the custom decoding first
extension LocationData {
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        name = try values.decode(String.self, forKey: .name)
        let location = try values.nestedContainer(keyedBy: LocationKeys.self, forKey: .location)
        lat = try location.decode(Double.self, forKey: .lat)
        lng = try location.decode(Double.self, forKey: .lng)
    }
}


extension LocationData {
    // This code overwrites the Encoder protocol method we get for free without our own custom method
    func encode(to encoder: Encoder) throws {
        // For the encoder, containers must be mutable since we'll be writing to them
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(name, forKey: .name)
        var latlng = encoder.container(keyedBy: LocationKeys.self)
        try latlng.encode(lat, forKey: .lat)
        try latlng.encode(lng, forKey: .lng)
    }
}

// Now, let's unflatten the JSON to fit this structure:

struct BusinessResultsNested : Codable {
    
    let results : [LocationDataNested]
    
    enum CodingKeys : String, CodingKey {
        case results = "results"
    }
}

struct LocationDataNested : Codable {
    
    let name : String
    let location : Location
    
    enum CodingKeys : String, CodingKey {
        case name = "name"
        case location = "location"
        case lat = "lat"
        case lng = "lng"
    }
    
    struct Location : Codable {
        let lat : Double
        let lng : Double
    }
    
}

extension LocationDataNested {
    init(from decoder : Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        name = try values.decode(String.self, forKey: .name)
        location = try Location(from: decoder)
    }
}

extension LocationDataNested {
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(name, forKey: .name)
        try container.encode(location, forKey : .location)
    }
}

var jsonData : Data?
if let path = Bundle.main.path(forResource: "Sample", ofType: "json") {
    jsonData = try? Data(contentsOf: URL(fileURLWithPath: path), options: .mappedIfSafe)
    let string = String(data: jsonData!, encoding: .utf8)
}

if let data = jsonData {
    let businessData = try! JSONDecoder().decode(BusinessResults.self, from: data)
    for data in businessData.results {
        print("******NEW BUSINESS******")
        print(data.name)
        print(data.lat)
        print(data.lng)
    }
    let encode = try JSONEncoder().encode(businessData)
    let string = String(data: encode, encoding: .utf8)
    let nestedDecode = try! JSONDecoder().decode(BusinessResultsNested.self, from: encode)
    for value in nestedDecode.results {
        print("******NEW BUSINESS******")
        print(value.name)
        print(value.location.lat)
        print(value.location.lng)
    }
    let nestedEncode = try! JSONEncoder().encode(nestedDecode)
    let nestedString = String(data: nestedEncode, encoding: .utf8)
}


