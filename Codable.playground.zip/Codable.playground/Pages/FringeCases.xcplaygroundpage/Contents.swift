//: [Previous](@previous)

import Foundation

struct Numbers : Decodable {
    let notNumber : Float
    let infinity : Float
    let negInfinity : Float
}

let decoder = JSONDecoder()
decoder.nonConformingFloatDecodingStrategy = .convertFromString(positiveInfinity: "+Infinity", negativeInfinity: "-Infinity", nan: "NaN")

var jsonData : Data?
if let path = Bundle.main.path(forResource: "Sample", ofType: "json") {
    jsonData = try? Data(contentsOf: URL(fileURLWithPath: path), options: .mappedIfSafe)
    let numbers = try decoder.decode(Numbers.self, from: jsonData!)
    dump(numbers)
}


