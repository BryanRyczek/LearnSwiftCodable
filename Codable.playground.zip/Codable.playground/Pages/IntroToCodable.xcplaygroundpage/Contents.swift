// Follow Along: https://github.com/BryanRyczek/LearnSwiftCodable

//  What is Codable?
//  Codable is a composition of two Swift Protocols: Encodable & Decodable. Codable is new to Swift 4.

// the literal definition of Codable in Swift is:
typealias Codable = Encodable & Decodable

//Encodable protocol definition is:
//public protocol Encodable {
//    func encode(to encoder: Encoder) throws
//}

//Decodable protocol definition:
//public protocol Decodable {
//    init(from decoder: Decoder) throws
//}

// What can you do with Codable?
// You can serialize and deserialize Classes, Structs & Enums easily.

//Does Codable support optional values?
//Yes. This is important because in some instances, your JSON may contain a key with a null value, or simply not contain the key : value pair at all. Marking the constant in Swift as optional allows us to handle both cases with one character, which is awesome!

// What is Serialization?
// Serialization is the process of translating data structures (like Classes, Structs & Enums) into a format that can be stored (like JSON or XML).

// What is Deserialization?
// Deserialization is translating stored formats like JSON to your Swift data structures!

// What types conform to Codable (i.e. what types can I use with Codable)?
// String, Int, Double, Data, Date & URL.
// Data structures Array, Dictionary & Optional conform to Codable as well. (MUST contain Codable types)

// What can't I do with Codable?
// extensions cannot conform to Codable. (Though you can extend Structs, Classes and Enums that conform to Codable.)

import Foundation
import CoreLocation

struct Business: Codable {
    let name : String
    let address : String
    let rating : Int
    let latitide : Double
    let longitude : Double
    let closeTime : Date
    let goodsSold : [String]
    let url : URL
}

struct Business2 : Codable {
    let name : String
    let address : String
    let rating : Int
    let closeTime : Date
    //You may notice that neither of our structs contains the methods that indicate conformance to our protocols:
    // func encode(to encoder: Encoder) throws
    // init(from decoder: Decoder) throws
    
    // As long as your types conform to Codable, you do not have to implement these methods.
    
    //  Even though a CLLocation can be created from two doubles, it will not conform to Codable .
    //let location : CLLocation
}

// How to Serialize an Object

let date = Date(timeIntervalSince1970: TimeInterval(exactly: 4950000006)!)

//Create an instance of my Object that conforms to Codable
let business = Business(name: "Bryan's Bagels", address: "123 Bagel Way", rating: 5, latitide: 42.1234, longitude: 74.660, closeTime: date, goodsSold: ["Bagels", "Schmear", "Coffee"], url: URL(string: "http://www.bryansbagels.com")!)

//Initialize instance of JSONEncoder
let encoder = JSONEncoder()
let jsonData = try encoder.encode(business)
/*
 
 // What is try?
 // try tells the compiler that a function, method, or initializer that can throw an error. In this case, JSONEncoder() may throw an error, so we must mark it with try.
 
 Here is the signature of .encode from the documentation
 
 open func encode<T>(_ value: T) throws -> Data where T : Encodable
 
 */

// Note: In a real app you would want to handle any error, that would look something like this:

var tryData : Data?
do {
    tryData = try encoder.encode(business)
} catch {
    print("json did not encode, oh well 🤷‍♂️🤷‍♀️!")
}

// Make a String from a JSON
let data = String(data: jsonData, encoding: .utf8)

//How to deserialize a JSON

//init decoder
let decoder = JSONDecoder()
//decode
let decodedBusiness = try decoder.decode(Business.self, from: jsonData)

//what is Business.self?
//in order to decode a json, the decoder needs to know the type of object it is dealing with. Dot self is how you reference a type in swift.

let businessName = decodedBusiness.name
let goodsSold = decodedBusiness.goodsSold
let url = decodedBusiness.url

// So that is a straight encode / decode. In the real world of JSON & dealing with RESTful services, things get a little more complicated!
