//: [Previous](@previous)

import Foundation
import CoreLocation

//create JSON with
//array of results
//key: String
//snake_case key: String
//optional key : String
//key: String array
//key: null value
//key: Int
//key: Double
//key: Object -> key: String key: String key: [String]

struct GeoPlacesResponse : Codable {
    let results : [GeoPlace]
    
    enum CodingKeys : String, CodingKey {
        case results = "results"
    }
}

struct GeoPlace : Codable {
    let name : String
    let lat : Double
    let lng : Double
    
    enum CodingKeys : String, CodingKey {
        case geometry = "geometry"
        case name = "name"
    }
    
    enum LocationKeys: String, CodingKey {
        case location
    }
    
    enum LatLngKeys : String, CodingKey {
        case lat
        case lng
    }
}

extension GeoPlace {
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        name = try values.decode(String.self, forKey: .name)
        let location = try values.nestedContainer(keyedBy: LocationKeys.self, forKey: .geometry)
        let latLng = try location.nestedContainer(keyedBy: LatLngKeys.self, forKey: .location)
        lat = try latLng.decode(Double.self, forKey: .lat)
        lng = try latLng.decode(Double.self, forKey: .lng)
    }
}

extension GeoPlace {
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(name, forKey: .name)
        var latlng = encoder.container(keyedBy: LatLngKeys.self)
        try latlng.encode(lat, forKey: .lat)
        try latlng.encode(lng, forKey: .lng)
    }
}


struct GooglePlacesResponse: Codable {
    
    let results : [GooglePlace]
    
    // here we have the enum conform to String so we can assign a rawValue to the enum cases
    enum CodingKeys : String, CodingKey {
        case results = "results"
    }
}

struct GooglePlace : Codable {
    
    let geometry : Location
    let id : String
    let name : String
    let openingHours : OpenNow? //Why is this an optional?
    let photos : [PhotoInfo]
    let types : [String]
    let address : String
    
    enum CodingKeys : String, CodingKey {
        case geometry = "geometry"
        case id = "id"
        case name = "name"
        case openingHours = "opening_hours" // we can rename from snake_case to camelCase
        case photos = "photos"
        case types = "types"
        case address = "vicinity"
    }
    
    struct OpenNow: Codable {
        let open : Bool
        
        enum CodingKeys : String, CodingKey {
            case open = "open_now"
        }
    }
    
    struct PhotoInfo : Codable {
        let height : Int
        let width : Int
        let photoReference : String
        
        var photoURL : URL {
            
            let baseURL = "https://maps.googleapis.com/maps/api/place/photo?"
            let photoRef = "&photoreference=" + photoReference
            let sensor = "&sensor=false"
            let maxHeight = "&maxheight=" + String(height)
            let maxWidth = "&maxwidth=" + String(width)
            let key = "&key=" + "AIzaSyBGOVvrHspeVjtaQsj0N6jqYdrwVsHsBQE"
            let urlString = baseURL + photoRef + sensor + maxHeight + maxWidth + key
            
            return URL(fileURLWithPath: urlString)
        }
        
        enum CodingKeys : String, CodingKey {
            case height = "height"
            case width = "width"
            case photoReference = "photo_reference"
        }
    }
    
    
    //We now need to create nested Structs to map the values found inside arrays in our JSON.address
    struct Location : Codable {
        let location : LatLong
        //computed property to give us easy access to the CLLocation, which is the object we really want to use in our code.
        var clLocation : CLLocation {
            return CLLocation(latitude: self.location.latitude, longitude: self.location.longitude)
        }
        enum CodingKeys: String, CodingKey {
            case location = "location"
        }
        
        // nested struct to actually capture the Doubles from "location : {}" object
        struct LatLong: Codable {
            let latitude : Double
            let longitude : Double
            
            enum CodingKeys : String, CodingKey {
                case latitude = "lat"
                case longitude = "lng"
            }
        }
        
    }
}

var jsonData : Data?
if let path = Bundle.main.path(forResource: "GooglePlacesResponse", ofType: "json") {
    jsonData = try? Data(contentsOf: URL(fileURLWithPath: path), options: .mappedIfSafe)
    let decoder = JSONDecoder()
    let flat = try! decoder.decode(GeoPlacesResponse.self, from: jsonData!)
    for response in flat.results {
        print(response.name)
        print(response.lng)
        print(response.lat)
    }
    let encode = try JSONEncoder().encode(flat)
    let s = String(data: encode, encoding: .utf8)
    let string = String(data: jsonData!, encoding: .utf8)
}
//if let data = jsonData {
//    let googlePlaces = try? JSONDecoder().decode(GooglePlacesResponse.self, from: data)
//
//    if let results = googlePlaces?.results {
//        for place in googlePlaces!.results {
//            print("***********new place***********")
//            print(place.address)
//            print(place.name)
//            if let oh = place.openingHours {
//               print(oh.open)
//            }
//            print(place.geometry.location.latitude)
//            print(place.geometry.location.longitude)
//            for type in place.types {
//                print(type)
//            }
//            for photo in place.photos {
//                print(photo.photoURL)
//            }
//        }
//    }
//}








