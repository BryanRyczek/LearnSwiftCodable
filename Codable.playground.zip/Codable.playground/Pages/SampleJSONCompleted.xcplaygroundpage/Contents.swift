//: [Previous](@previous)

import Foundation
import UIKit

struct BusinessResults : Codable {
    // example of handling key : [Object]
    let results : [BusinessData]
    
    enum CodingKeys : CodingKey, String {
        case results = "results"
    }
}

struct BusinessData: Codable {
    
    // example of key: String
    let name : String
    // example of key : Array
    let businessType : [String]
    // example of optional key
    let openNow : Bool?
    // example of omitting a key : value pair found in our JSON
    //let managerName : String
    // example of URL
    let website : URL
    // example of key : Object
    let location : Location
    // example of key : Int
    let peopleServed : Int
    // example of key : Data
    let imageData : Data?
    // example of formatting Date
    let established : Date?
    // Notes on Date: Encoder defaults to .deferredToDate setting (takes the default setting of Date).
    // If the date in your JSON is .iso8601 encoded, change the dateEncodingStrategy property on the Encoder. There are also options for .secondsSince1970, .custom, etc.
    // encoder.dateEncodingStrategy = .iso8601
    
    //enum MUST be named CodingKeys & MUST conform to CodingKey & String
    enum CodingKeys : String, CodingKey {
        case name = "name"
        case businessType = "business_type"
        case openNow = "open_now"
        //case managerName = "manager_name"
        case website // if your JSON key matches your constant name, you do not have to define a rawValue.
        case location // but you DO still have to define a case for the constant.
        case peopleServed
        case imageData = "imageData"
        case established
    }
    
    struct Location : Codable {
        // Can this struct be non-nested?
        // Yes, but it is doubtful I use this struct outside the scope of BusinessData so I am going to nest it.
        let address : Address
        let latitude : Double
        let longitude : Double
        
        enum CodingKeys : CodingKey, String {
            case latitude = "lat"
            case longitude = "lng"
            case address
        }
        
        struct Address : Codable {
            let streetAddress1 : String
            let streetAddress2 : String?
            let city : String
            let state : String
            let zip : String // In Javascript, Zip codes are always stored as a string!
            
            enum CodingKeys : String, CodingKey {
                case streetAddress1 = "street_address1"
                case streetAddress2 = "street_address2"
                case city
                case state
                case zip
            }
        }
    }
    
}

var jsonData : Data?
// load the JSON from our Bundle
if let path = Bundle.main.path(forResource: "Sample", ofType: "json") {
    jsonData = try? Data(contentsOf: URL(fileURLWithPath: path), options: .mappedIfSafe)
    let string = String(data: jsonData!, encoding: .utf8)
}

if let data = jsonData {
    let businessData = try? JSONDecoder().decode(BusinessResults.self, from: data)
    
    if let bizResults = businessData?.results {
        
        for result in bizResults {
            print("*******NEW BUSINESS********")
            print(result.established)
            print("\(result.name) - over \(result.peopleServed) served")
            print("Visit us at \(result.location.address.streetAddress1), \(result.location.address.state), \(result.location.address.state), or online at \(result.website)")
            if let imageData = result.imageData {
                
                let image = UIImage(data: imageData)
                let imageView = UIImageView(image: image)
            }
            
        }
    }
}
