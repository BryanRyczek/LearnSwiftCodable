//: [Previous](@previous)

import Foundation

struct MenuPlan : Codable {
    let sandwiches : [BagelSandwich]
    
    enum CodingKeys: String, CodingKey {
        case sandwiches
    }
}

struct BagelSandwich : Codable {
    let name : String
    let financials : Financials
    let toppings : [String]?
    let bagelType : String
    
    enum CodingKeys: String, CodingKey {
        case name
        case financials
        case toppings
        case bagelType = "bagel_type"
    }
    
    struct Financials : Codable {
        let cost : Double
        let price : Double
    }
}

extension BagelSandwich {
    func encode(to encoder: Encoder) throws {
        //Containers: There are three types:
                //Keyed (Dict) represented by .nestedContainer
                //Unkeyed (array) represented by .nestedUnkeyedContainer
                //and singleValue (raw value), represented by .encode
        // Containers must be mutable since we'll be writing to them.
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(name, forKey: .name)
        try container.encode(financials, forKey: .financials)
        //since toppings is optional, Encodeable will use .encodeIfPresent by default. If we want our JSON to include a "toppings" key with a null value no matter what, we have to override that here.
        try container.encode(toppings, forKey: .toppings)
        try container.encode(bagelType, forKey: .bagelType)
    }
}

extension BagelSandwich {
    init(from decoder: Decoder) throws {
        // define container
        let container = try decoder.container(keyedBy: CodingKeys.self)
        //manual decode statements for each type & key combination
        let name = try container.decode(String.self, forKey: .name)
        let financials = try container.decode(Financials.self, forKey: .financials)
        //handling the array
        var toppingsArray = try container.nestedUnkeyedContainer(forKey: .toppings)
        var toppings : [String] = []
        //iterate through each item in toppingsArray and append.
        while (!toppingsArray.isAtEnd) {
            let topping = try toppingsArray.decode(String.self)
            toppings.append(topping)
        }
        let bagelType = try container.decode(String.self, forKey: .bagelType)
        self.init(name: name, financials: financials, toppings: toppings, bagelType: bagelType)
    }
}

let lox = BagelSandwich(name: "lox", financials: BagelSandwich.Financials(cost: 2.52, price: 6.98), toppings: ["Cream Cheese", "lox", "onion", "capers", "tomato"], bagelType: "everything")
let brekkie = BagelSandwich(name: "breakfast", financials: BagelSandwich.Financials(cost: 1.79, price: 5.50), toppings: ["egg", "bacon", "cheese"], bagelType: "onion")
let currentMenuPlan : MenuPlan = MenuPlan(sandwiches: [lox,brekkie])

let encoder = JSONEncoder()
let menuPlan = try encoder.encode(currentMenuPlan)
let data = String(data: menuPlan, encoding: .utf8)

struct Menu : Codable {
    let sandwiches : [BagelSandwichCondensed]
    
}

struct BagelSandwichCondensed : Codable {
    var name : String
    var price : Double
    
    enum CodingKeys : String, CodingKey {
        case name
        case financials
    }
    
    enum FinancialsKeys : String, CodingKey {
        case price
    }
    
}

extension BagelSandwichCondensed {
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        name = try values.decode(String.self, forKey: .name)
        let financials = try values.nestedContainer(keyedBy: FinancialsKeys.self, forKey: .financials)
        price = try financials.decode(Double.self, forKey: .price)
    }
}

extension BagelSandwichCondensed {
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(name, forKey: .name)
        var financials = encoder.container(keyedBy: FinancialsKeys.self)
        try financials.encode(price, forKey: .price)
    }
}

let decoder = JSONDecoder()
let menu = try decoder.decode(Menu.self, from: menuPlan)
let json = try encoder.encode(menu)
let data1 = String(data: json, encoding: .utf8)
