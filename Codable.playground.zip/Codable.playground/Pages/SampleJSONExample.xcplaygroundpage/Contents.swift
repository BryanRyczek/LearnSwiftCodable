//: [Previous](@previous)
//
//import Foundation
//import UIKit
//
////In this example, I'm going to take a JSON that I have written and complete the Data structures needed to conform to Codable.
//
///*
//
//struct BusinessResults : Codable {
//    // example of handling key : [Object]
//    
//    enum CodingKeys : CodingKey, String {
//    }
//}
//
//struct BusinessData: Codable {
//    
//    // example of key: String
//    
//    // example of key : Array
//    
//    // example of optional key
//    
//    // example of omitting a key : value pair found in our JSON
//    
//    // example of URL
//    
//    // example of key : Object
//    
//    // example of key : Int
//    
//    // example of key : Data
//    
//    // example of formatting Date
//    
//    // Notes on Date: Encoder defaults to .deferredToDate setting (takes the default setting of Date).
//    // If the date in your JSON is .iso8601 encoded, ("2017-11-16T02:02:55.000-08:00") change the dateEncodingStrategy property on the Encoder. There are also options for .secondsSince1970, .custom, etc.
//    // encoder.dateEncodingStrategy = .iso8601
//    
//    //enum MUST be named CodingKeys & MUST conform to CodingKey & String
//    enum CodingKeys : String, CodingKey {
//    }
//
//    struct Location : Codable {
//    // Can this struct be non-nested?
//    // Yes, but it is doubtful I use this struct outside the scope of BusinessData so I am going to nest it.
//        
//        
//        enum CodingKeys : CodingKey, String {
//        }
//        
//        struct Address : Codable {
//            
//            
//            enum CodingKeys : String, CodingKey {
//            }
//        }
//    }
//    
//}
// 
//*/
//
//var jsonData : Data?
//// load the JSON from our Bundle
//if let path = Bundle.main.path(forResource: "Sample", ofType: "json") {
//    jsonData = try? Data(contentsOf: URL(fileURLWithPath: path), options: .mappedIfSafe)
//    let string = String(data: jsonData!, encoding: .utf8)
//}
//
//if let data = jsonData {
//    let businessData = try? JSONDecoder().decode(BusinessResults.self, from: data)
//    
//    if let bizResults = businessData?.results {
//        
//        for result in bizResults {
//            print("*******NEW BUSINESS********")
//            if let established = result.established {
//                print(established)
//            }
//            print("\(result.name) - over \(result.peopleServed) served")
//            print("Visit us at \(result.location.address.streetAddress1), \(result.location.address.state), \(result.location.address.state), or online at \(result.website)")
//            if let imageData = result.imageData {
//                
//                let image = UIImage(data: imageData)
//                let imageView = UIImageView(image: image)
//            }
//            
//        }
//    }
//}

